import logo from "./logo.svg";
import "./App.css";
import Garage from "./Garage";
import Student from "./Student";
import Car from "./Car";
import Header from "./Header";

function App() {
    return (
        <div className="App">
            <Garage />
            {/* <Student />
            <Car />
            <Header favcol="yellow" /> */}
        </div>
    );
}

export default App;
